local({
  lib_nova <- path.expand("~/R/biblioteca-mapas-R46")
  lib_antiga <- path.expand("~/R/x86_64-pc-linux-gnu-library/4.6")
  .libPaths(c(lib_nova, lib_antiga, .Library), include.site = FALSE)
})

options(repos = c(
  CRAN = "https://packagemanager.posit.co/cran/latest/bin/linux/noble-x86_64/4.6"
))
