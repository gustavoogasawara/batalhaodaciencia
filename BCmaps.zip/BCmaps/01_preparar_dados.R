# ============================================================
# 01_preparar_dados.R
# Comunidade WhatsApp: prefixos de telefone -> dados agregados
# Origem: ddddata(1).csv, coluna "primeiros".
# Importante: um registro nao equivale necessariamente a uma pessoa.
# ============================================================

pacotes <- c("dplyr")
faltantes <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltantes)) stop("Instale os pacotes: ", paste(faltantes, collapse = ", "))

dir.create("resultados", showWarnings = FALSE, recursive = TRUE)
arquivo <- Sys.getenv("ARQUIVO_DADOS", unset = "ddddata(1).csv")
if (!file.exists(arquivo)) stop("Arquivo nao encontrado: ", arquivo,
                                "\nColoque o CSV nesta pasta ou defina ARQUIVO_DADOS.")

# Tratamento como TEXTO: nunca converta prefixos em numeros.
entrada <- utils::read.csv(arquivo, fileEncoding = "UTF-8-BOM",
                           colClasses = "character", check.names = FALSE,
                           stringsAsFactors = FALSE)
if (!"primeiros" %in% names(entrada)) {
  stop("Esperava uma coluna chamada 'primeiros'. Colunas encontradas: ",
       paste(names(entrada), collapse = ", "))
}
prefixos <- trimws(entrada$primeiros)
prefixos <- sub("^\\+", "", prefixos)
prefixos <- prefixos[!is.na(prefixos) & nzchar(prefixos)]
if (any(!grepl("^[0-9]+$", prefixos))) {
  stop("Alguns prefixos possuem caracteres inesperados. Confira o CSV.")
}

# Tabela completa de DDDs por estado ou area (fonte: MCom / Anatel).
# DDD 61 e intencionalmente AMBIGUO entre DF e GO.
ddd_por_area <- list(
  SP = 11:19,
  RJ = c(21, 22, 24),
  ES = c(27, 28),
  MG = c(31, 32, 33, 34, 35, 37, 38),
  PR = 41:46,
  SC = 47:49,
  RS = c(51, 53, 54, 55),
  `DF/GO` = 61,
  GO = c(62, 64),
  MT = c(65, 66),
  MS = 67,
  AC = 68,
  RO = 69,
  TO = 63,
  PA = c(91, 93, 94),
  AM = c(92, 97),
  RR = 95,
  AP = 96,
  BA = c(71, 73, 74, 75, 77),
  SE = 79,
  PE = c(81, 87),
  AL = 82,
  PB = 83,
  RN = 84,
  CE = c(85, 88),
  PI = c(86, 89),
  MA = c(98, 99)
)

referencia_ddd <- dplyr::bind_rows(lapply(names(ddd_por_area), function(area) {
  data.frame(ddd = sprintf("%02d", ddd_por_area[[area]]),
             uf_area = area, stringsAsFactors = FALSE)
}))
stopifnot(!anyDuplicated(referencia_ddd$ddd))

ufs_regiao <- c(
  AC = "Norte", AP = "Norte", AM = "Norte", PA = "Norte",
  RO = "Norte", RR = "Norte", TO = "Norte",
  AL = "Nordeste", BA = "Nordeste", CE = "Nordeste",
  MA = "Nordeste", PB = "Nordeste", PE = "Nordeste",
  PI = "Nordeste", RN = "Nordeste", SE = "Nordeste",
  DF = "Centro-Oeste", GO = "Centro-Oeste",
  MT = "Centro-Oeste", MS = "Centro-Oeste",
  ES = "Sudeste", MG = "Sudeste", RJ = "Sudeste", SP = "Sudeste",
  PR = "Sul", RS = "Sul", SC = "Sul"
)
referencia_ddd$regiao <- unname(ufs_regiao[
  ifelse(referencia_ddd$uf_area == "DF/GO", "DF", referencia_ddd$uf_area)
])
stopifnot(!anyNA(referencia_ddd$regiao))

br <- prefixos[startsWith(prefixos, "55")]
exterior <- prefixos[!startsWith(prefixos, "55")]
ddd_br <- substr(br, 3, 4)
if (any(nchar(br) < 4)) stop("Prefixo +55 incompleto no arquivo.")
nao_reconhecidos <- setdiff(unique(ddd_br), referencia_ddd$ddd)
if (length(nao_reconhecidos)) {
  stop("DDD(s) brasileiros nao reconhecidos: ",
       paste(nao_reconhecidos, collapse = ", "),
       "\nRevise a identificacao e evite classificar automaticamente.")
}

por_ddd <- data.frame(ddd = ddd_br, stringsAsFactors = FALSE) |>
  dplyr::count(ddd, name = "n") |>
  dplyr::left_join(referencia_ddd, by = "ddd") |>
  dplyr::select(ddd, uf_area, regiao, n) |>
  dplyr::arrange(dplyr::desc(n), ddd)

por_uf <- por_ddd |>
  dplyr::group_by(uf_area, regiao) |>
  dplyr::summarise(n = sum(n), .groups = "drop") |>
  dplyr::arrange(dplyr::desc(n), uf_area)

ordem_regioes <- c("Sudeste", "Nordeste", "Sul", "Centro-Oeste", "Norte")
por_regiao <- por_ddd |>
  dplyr::group_by(regiao) |>
  dplyr::summarise(n = sum(n), .groups = "drop") |>
  dplyr::mutate(percentual = round(100 * n / length(br), 1)) |>
  dplyr::arrange(match(regiao, ordem_regioes))

# Codigos internacionais presentes no CSV; +1 nao identifica pais isoladamente.
# Se o arquivo mudar, um codigo nao reconhecido sera colocado como "Nao identificado".
paises_referencia <- data.frame(
  ddi = c("351", "353", "244", "61", "41", "44", "49", "62", "1"),
  pais = c("Portugal", "Irlanda", "Angola", "Austrália", "Suíça",
           "Reino Unido", "Alemanha", "Indonésia", "Código +1 (país indefinido)"),
  iso3 = c("PRT", "IRL", "AGO", "AUS", "CHE", "GBR", "DEU", "IDN", ""),
  stringsAsFactors = FALSE
)

identificar_ddi <- function(x) {
  alternativas <- paises_referencia$ddi[startsWith(x, paises_referencia$ddi)]
  if (!length(alternativas)) return(NA_character_)
  alternativas[which.max(nchar(alternativas))]
}

ddis <- vapply(exterior, identificar_ddi, character(1))
por_pais_ext <- data.frame(ddi = ddis, stringsAsFactors = FALSE) |>
  dplyr::count(ddi, name = "n") |>
  dplyr::left_join(paises_referencia, by = "ddi") |>
  dplyr::mutate(pais = dplyr::coalesce(pais, "Não identificado"),
                iso3 = dplyr::coalesce(iso3, "")) |>
  dplyr::select(pais, ddi, iso3, n)

por_pais <- dplyr::bind_rows(
  data.frame(pais = "Brasil", ddi = "55", iso3 = "BRA", n = length(br)),
  por_pais_ext
) |> dplyr::arrange(dplyr::desc(n), pais)

# Invariantes: nenhum registro se perde ou e contado duas vezes.
stopifnot(sum(por_ddd$n) == length(br))
stopifnot(sum(por_uf$n) == length(br))
stopifnot(sum(por_regiao$n) == length(br))
stopifnot(sum(por_pais$n) == length(prefixos))

# Exporta APENAS frequencias agregadas, nunca telefones/prefixos individuais.
utils::write.csv(por_ddd, "resultados/contagem_por_ddd.csv", row.names = FALSE,
                 fileEncoding = "UTF-8")
utils::write.csv(por_uf, "resultados/contagem_por_uf.csv", row.names = FALSE,
                 fileEncoding = "UTF-8")
utils::write.csv(por_regiao, "resultados/contagem_por_regiao.csv", row.names = FALSE,
                 fileEncoding = "UTF-8")
utils::write.csv(por_pais, "resultados/contagem_por_pais.csv", row.names = FALSE,
                 fileEncoding = "UTF-8")

resumo <- c(
  sprintf("Linhas validas do CSV: %d", length(prefixos)),
  sprintf("Prefixos distintos (NAO deduplicar, pois estao truncados): %d", length(unique(prefixos))),
  sprintf("Prefixos brasileiros: %d", length(br)),
  sprintf("Prefixos internacionais: %d", length(exterior)),
  sprintf("DDDs distintos no Brasil: %d", dplyr::n_distinct(ddd_br)),
  sprintf("DDD 61 (DF e parte de GO, sem atribuir UF): %d", sum(ddd_br == "61")),
  sprintf("DDD 95 (Roraima): %d", sum(ddd_br == "95")),
  "Membros na comunidade informados anteriormente: 589 (nao confirmado pelo CSV).",
  "A diferenca 591 x 589 nao esta resolvida.",
  "A distribuicao geografica por DDD nao indica residencia atual.",
  "Codigo +1 inclui EUA, Canada e territorios do Caribe: nao fixar um unico pais."
)
writeLines(resumo, "resultados/resumo_qualidade.txt", useBytes = TRUE)
cat(paste(resumo, collapse = "\n"), "\n")
