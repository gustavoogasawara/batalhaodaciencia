# ============================================================
# 02_mapa_brasil.R
# Mapa de bolhas por UF/area + painel de regioes brasileiras.
# Bases geograficas reais de UF: geobr (IBGE/IPEA).
# DDD 61 e mostrado separadamente, proximo de Brasilia.
# ============================================================

pacotes <- c("dplyr", "sf", "ggplot2", "geobr", "patchwork", "scales")
faltantes <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltantes)) stop("Instale os pacotes: ", paste(faltantes, collapse = ", "))

pasta <- "resultados"
necessarios <- file.path(pasta, c("contagem_por_ddd.csv", "contagem_por_uf.csv", "contagem_por_regiao.csv"))
if (any(!file.exists(necessarios))) stop("Execute 01_preparar_dados.R primeiro.")

por_ddd <- utils::read.csv(file.path(pasta, "contagem_por_ddd.csv"),
                           colClasses = c("character", "character", "character", "integer"))
por_uf <- utils::read.csv(file.path(pasta, "contagem_por_uf.csv"), stringsAsFactors = FALSE)
por_regiao <- utils::read.csv(file.path(pasta, "contagem_por_regiao.csv"), stringsAsFactors = FALSE)

cores <- c(
  "Norte" = "#388AA0", "Nordeste" = "#E29A55",
  "Centro-Oeste" = "#9873BC", "Sudeste" = "#147980", "Sul" = "#61A17F"
)

# Obs.: a primeira execucao precisa de acesso a internet para baixar malhas.
estados <- geobr::read_state(code_state = "all", year = 2022,
                             simplified = TRUE, showProgress = FALSE)
if (!"abbrev_state" %in% names(estados)) {
  stop("A malha do geobr nao contem 'abbrev_state'. Verifique a versao instalada.")
}

# Nao inventar alocacao do DDD 61 (DF/GO) para uma das duas UFs.
uf_exatas <- por_uf |>
  dplyr::filter(uf_area != "DF/GO") |>
  dplyr::transmute(abbrev_state = uf_area, n = as.integer(n), regiao)

malha <- estados |>
  dplyr::left_join(uf_exatas, by = "abbrev_state") |>
  dplyr::mutate(n = dplyr::coalesce(n, 0L))
# Cada geometria e transformada para um sistema projetado ANTES de fazer pontos.
malha_proj <- sf::st_transform(malha, 5880)
pontos <- sf::st_point_on_surface(malha_proj)
pontos <- dplyr::filter(pontos, n > 0)

# DDD 61: ponto simbolico (Brasil/DF e entorno de GO), nao geolocalizacao.
qtd_61 <- por_ddd$n[por_ddd$ddd == "61"]
if (!length(qtd_61)) qtd_61 <- 0L
ponto_61 <- sf::st_as_sf(data.frame(lon = -47.8825, lat = -15.7942, n = qtd_61),
                          coords = c("lon", "lat"), crs = 4326) |>
  sf::st_transform(5880)

rotulos <- pontos |>
  dplyr::filter(n >= 18) |>
  dplyr::mutate(rotulo = paste0(abbrev_state, "\n", n))

mapa <- ggplot2::ggplot() +
  ggplot2::geom_sf(data = malha_proj, fill = "#E9F0EF", color = "#A5BCBB", linewidth = 0.3) +
  ggplot2::geom_sf(data = pontos,
                   ggplot2::aes(size = n, color = regiao), alpha = 0.87) +
  ggplot2::geom_sf(data = ponto_61, ggplot2::aes(size = n),
                   shape = 21, fill = "#DBBFEA", color = "#603B7E", stroke = 1.1) +
  ggplot2::geom_sf_text(data = rotulos, ggplot2::aes(label = rotulo),
                        size = 3.0, fontface = "bold", color = "#183D42",
                        check_overlap = TRUE) +
  ggplot2::scale_color_manual(values = cores, drop = FALSE, name = "Região") +
  ggplot2::scale_size_area(max_size = 17, breaks = c(5, 20, 50, 100, 188),
                           name = "Registros") +
  ggplot2::coord_sf(datum = NA, expand = FALSE) +
  ggplot2::labs(subtitle = "Círculos proporcionais aos registros por UF; DDD 61 destacado sobre Brasília") +
  ggplot2::theme_void(base_size = 12) +
  ggplot2::theme(
    plot.subtitle = ggplot2::element_text(color = "#587174", margin = ggplot2::margin(b = 12)),
    legend.position = "bottom", legend.box = "vertical",
    plot.margin = ggplot2::margin(12, 10, 12, 10)
  )

por_regiao$regiao <- factor(
  por_regiao$regiao,
  levels = rev(c("Sudeste", "Nordeste", "Sul", "Centro-Oeste", "Norte"))
)
painel <- ggplot2::ggplot(
  por_regiao,
  ggplot2::aes(x = regiao, y = n, fill = regiao)
) +
  ggplot2::geom_col(width = 0.65) +
  ggplot2::geom_text(
    ggplot2::aes(label = sprintf("%d (%.1f%%)", n, percentual)),
    hjust = -0.05, size = 3.7, color = "#24464A"
  ) +
  ggplot2::scale_fill_manual(values = cores, guide = "none") +
  ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.35))) +
  ggplot2::coord_flip(clip = "off") +
  ggplot2::labs(title = "Por região", x = NULL, y = "Registros") +
  ggplot2::theme_minimal(base_size = 12) +
  ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(),
                 panel.grid.minor = ggplot2::element_blank(),
                 plot.title = ggplot2::element_text(face = "bold", color = "#173B42"),
                 axis.text.y = ggplot2::element_text(face = "bold"),
                 plot.margin = ggplot2::margin(12, 28, 12, 2))

br_total <- sum(por_regiao$n)
top_ddd <- head(por_ddd, 5)
texto_top <- paste(paste0(top_ddd$ddd, ": ", top_ddd$n), collapse = "   •   ")
figura <- (mapa + painel + patchwork::plot_layout(widths = c(1.7, 1))) +
  patchwork::plot_annotation(
    title = "COMUNIDADE PELO BRASIL",
    subtitle = sprintf("Distribuição dos prefixos telefônicos • %d registros brasileiros • %d DDDs", br_total, nrow(por_ddd)),
    caption = paste0(
      "Principais DDDs: ", texto_top, "\n",
      "DDD 61 (n=", qtd_61, ") cobre DF e parte de GO, sem atribuição individual de estado. ",
      "Registros não equivalem necessariamente a membros únicos."
    ),
    theme = ggplot2::theme(
      plot.title = ggplot2::element_text(size = 22, face = "bold", color = "#173B42"),
      plot.subtitle = ggplot2::element_text(size = 12, color = "#547478"),
      plot.caption = ggplot2::element_text(size = 9, color = "#536D70", hjust = 0)
    )
  )

ggplot2::ggsave(file.path(pasta, "mapa_brasil_regioes.png"), plot = figura,
                width = 15, height = 9.6, dpi = 260, bg = "white")
ggplot2::ggsave(file.path(pasta, "mapa_brasil_regioes.svg"), plot = figura,
                width = 15, height = 9.6, device = "svg", bg = "white")
cat("Criados:", file.path(pasta, "mapa_brasil_regioes.png"), "e SVG\n")
