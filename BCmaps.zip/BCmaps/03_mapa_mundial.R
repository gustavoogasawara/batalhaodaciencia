# ============================================================
# 03_mapa_mundial.R
# Mapa do mundo com pontos por pais e quadro de frequencias.
# Codigo +1 fica SEM pais no mapa: cobre varios paises/territorios.
# ============================================================

pacotes <- c("dplyr", "sf", "ggplot2", "rnaturalearth", "rnaturalearthdata", "patchwork")
faltantes <- pacotes[!vapply(pacotes, requireNamespace, logical(1), quietly = TRUE)]
if (length(faltantes)) stop("Instale os pacotes: ", paste(faltantes, collapse = ", "))

pasta <- "resultados"
arquivo <- file.path(pasta, "contagem_por_pais.csv")
if (!file.exists(arquivo)) stop("Execute 01_preparar_dados.R primeiro.")
por_pais <- utils::read.csv(arquivo, stringsAsFactors = FALSE)
por_pais$iso3[is.na(por_pais$iso3)] <- ""

paises_mundo <- rnaturalearth::ne_countries(scale = 110, returnclass = "sf")
if (!"iso_a3" %in% names(paises_mundo)) stop("Malha mundial sem 'iso_a3'.")

# Unimos SOMENTE codigos ISO-3 que identificam um pais sem ambiguidade.
identificados <- por_pais |>
  dplyr::filter(nzchar(iso3)) |>
  dplyr::select(iso3, n, pais)

mundo <- paises_mundo |>
  dplyr::left_join(identificados, by = c("iso_a3" = "iso3")) |>
  dplyr::mutate(
    n = dplyr::coalesce(n, 0L),
    classe = dplyr::case_when(
      iso_a3 == "BRA" ~ "Brasil",
      n > 0 ~ "Outros países",
      TRUE ~ "Sem registros"
    )
  )

# Projecao Robinson para melhor visualizacao global.
proj <- "+proj=robin +lon_0=0 +datum=WGS84 +units=m +no_defs"
mundo_proj <- sf::st_transform(mundo, crs = proj)
pontos <- sf::st_point_on_surface(dplyr::filter(mundo_proj, n > 0))

# Rotula os dois principais destaques, sem supor um pais para o codigo +1.
rotulos <- pontos |>
  dplyr::filter(iso_a3 %in% c("BRA", "AUS")) |>
  dplyr::mutate(rotulo = paste0(pais, "\n", n))

mapa <- ggplot2::ggplot() +
  ggplot2::geom_sf(data = mundo_proj, ggplot2::aes(fill = classe),
                   color = "#B9CAC8", linewidth = 0.16) +
  ggplot2::geom_sf(data = pontos, ggplot2::aes(size = n),
                   shape = 21, fill = "#0E777D", color = "white", stroke = 0.5,
                   alpha = 0.92) +
  ggplot2::geom_sf_text(data = rotulos, ggplot2::aes(label = rotulo),
                        fontface = "bold", color = "#183C42", size = 3.0,
                        nudge_y = 700000) +
  ggplot2::scale_fill_manual(
    values = c("Brasil" = "#6BB4A8", "Outros países" = "#E3A66C",
               "Sem registros" = "#E9F0EE"),
    name = "Países"
  ) +
  ggplot2::scale_size(range = c(3, 22), breaks = c(1, 2, 3, 6, 18, 573),
                      name = "Registros") +
  ggplot2::coord_sf(datum = NA, expand = FALSE) +
  ggplot2::theme_void(base_size = 12) +
  ggplot2::theme(legend.position = "bottom",
                 plot.margin = ggplot2::margin(10, 10, 10, 10))

exterior <- por_pais |>
  dplyr::filter(pais != "Brasil") |>
  dplyr::arrange(n, pais) |>
  dplyr::mutate(pais = factor(pais, levels = pais),
                classe = ifelse(nzchar(iso3), "País identificado", "Código não localizado"))

painel <- ggplot2::ggplot(exterior, ggplot2::aes(x = pais, y = n, fill = classe)) +
  ggplot2::geom_col(width = 0.65) +
  ggplot2::geom_text(ggplot2::aes(label = n), hjust = -0.15,
                     size = 3.8, color = "#24464A") +
  ggplot2::scale_fill_manual(
    values = c("País identificado" = "#0E777D", "Código não localizado" = "#9873BC"),
    guide = "none") +
  ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.3))) +
  ggplot2::coord_flip(clip = "off") +
  ggplot2::labs(title = "Registros internacionais", x = NULL, y = "Registros") +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(panel.grid.major.y = ggplot2::element_blank(),
                 panel.grid.minor = ggplot2::element_blank(),
                 axis.text.y = ggplot2::element_text(size = 9.4),
                 plot.title = ggplot2::element_text(face = "bold", color = "#173B42"),
                 plot.margin = ggplot2::margin(12, 18, 12, 2))

figura <- (mapa + painel + patchwork::plot_layout(widths = c(2.1, 1))) +
  patchwork::plot_annotation(
    title = "COMUNIDADE PELO MUNDO",
    subtitle = sprintf("Distribuição dos prefixos telefônicos • %d registros no Brasil • %d no exterior",
                       sum(por_pais$n[por_pais$pais == "Brasil"]),
                       sum(por_pais$n[por_pais$pais != "Brasil"])),
    caption = paste(
      "Os prefixos não indicam localização atual. O código +1 corresponde a diferentes países/territórios",
      "e foi omitido dos pontos geográficos. 591 registros na fonte para 589 membros informados."
    ),
    theme = ggplot2::theme(
      plot.title = ggplot2::element_text(size = 22, face = "bold", color = "#173B42"),
      plot.subtitle = ggplot2::element_text(size = 12, color = "#547478"),
      plot.caption = ggplot2::element_text(size = 9, color = "#536D70", hjust = 0)
    )
  )

ggplot2::ggsave(file.path(pasta, "mapa_mundial.png"), plot = figura,
                width = 16, height = 8.7, dpi = 260, bg = "white")
ggplot2::ggsave(file.path(pasta, "mapa_mundial.svg"), plot = figura,
                width = 16, height = 8.7, device = "svg", bg = "white")
cat("Criados:", file.path(pasta, "mapa_mundial.png"), "e SVG\n")
