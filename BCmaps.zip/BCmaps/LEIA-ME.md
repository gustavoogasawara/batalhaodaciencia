# Mapas geográficos da comunidade WhatsApp (R)

Os scripts reproduzem o **mapa do Brasil com bolhas por UF e gráfico por macrorregião** e o **mapa mundial com pontos por país e painel internacional** a partir dos prefixos já reduzidos presentes no CSV.

## Como usar (Ubuntu + RStudio ou terminal)

1. Extraia o `.zip` e mantenha `ddddata(1).csv` na mesma pasta dos `.R`.
2. No R, instale os pacotes necessários (uma única vez):

```r
install.packages(c(
  "dplyr", "ggplot2", "sf", "geobr", "rnaturalearth",
  "rnaturalearthdata", "patchwork", "scales"
))
```

   - No Ubuntu, o pacote R `sf` pode exigir dependências do sistema: `sudo apt install libgdal-dev libgeos-dev libproj-dev libudunits2-dev`.
3. Abra o RStudio, selecione a pasta do projeto como diretório de trabalho (**Session > Set Working Directory > Choose Directory**) e execute:

```r
source("executar_tudo.R", encoding = "UTF-8")
```

   Ou no terminal, a partir dessa pasta:

```bash
Rscript executar_tudo.R
```

4. Confira a pasta `resultados/` com os arquivos abaixo.

## Arquivos produzidos

- `contagem_por_ddd.csv`: frequência por DDD e classificação regional.
- `contagem_por_uf.csv`: frequência por UF ou área DDD 61 (DF/GO).
- `contagem_por_regiao.csv`: frequência e percentual por macrorregião.
- `contagem_por_pais.csv`: frequência por DDI/país; o código +1 aparece como indefinido.
- `resumo_qualidade.txt`: verificações da base de entrada.
- `mapa_brasil_regioes.png` e `.svg`: mapa e painel regional.
- `mapa_mundial.png` e `.svg`: mapa mundial e painel internacional.

## Como modificar

- **DDD para UF/região:** editar `ddd_por_area` em `01_preparar_dados.R`.
- **Países/códigos internacionais:** editar `paises_referencia` no mesmo arquivo.
- **Cores e bolhas do Brasil:** editar `cores` e `scale_size_area()` em `02_mapa_brasil.R`.
- **Mapa mundial:** editar `03_mapa_mundial.R`.
- **Manter somente Brasil:** executar `01_preparar_dados.R`, depois `02_mapa_brasil.R`.

## Observações metodológicas importantes

- **591 registros** na planilha, ante **589 membros** informados na comunidade. A origem dessa diferença é desconhecida.
- **573 prefixos iniciam com 55; 18 são internacionais.** Há **54 DDDs** brasileiros distintos.
- **547 prefixos diferentes** na planilha reduzida; não são 547 membros únicos. Os 5 dígitos finais foram removidos, de modo que pessoas diferentes podem ficar com prefixos iguais. Os scripts **não deduplicam**.
- O **DDD 61** atende DF e parte de GO. Ele é **apontado simbolicamente na região de Brasília** e contabilizado no Centro-Oeste, sem atribuir os registros exclusivamente a DF ou GO.
- O código internacional **+1** não permite distinguir EUA, Canadá e diversos territórios/caribenhos apenas pelos poucos dígitos disponíveis; seus registros ficam no painel, sem ponto arbitrário no mapa.
- **Não há DDD 95** nesta versão do CSV: o script não cria ponto em Roraima.
- O mapa de UF usa **pontos no interior de cada UF**, não localizações reais dos participantes nem as posições exatas das áreas de DDD.
- Os PNG e SVG são feitos com malhas oficiais via `geobr` (UFs) e Natural Earth via `rnaturalearth` (países). A primeira execução geralmente requer internet para a malha do Brasil.
- Os CSV de saída contêm **apenas frequências agregadas**. Não compartilhe o CSV de origem se não for necessário.

## Fontes para revisão

- Ministério das Comunicações: https://www.gov.br/mcom/pt-br/noticias/2026/agosto/saiba-a-importancia-da-discagem-direta-a-distancia-ddd
- `geobr`: https://cran.r-project.org/package=geobr
- `rnaturalearth`: https://docs.ropensci.org/rnaturalearth/reference/ne_countries.html
