# Execute com: Rscript executar_tudo.R
# Ou, no RStudio: setwd("diretorio/do/projeto"); source("executar_tudo.R")
source("01_preparar_dados.R", encoding = "UTF-8")
source("02_mapa_brasil.R", encoding = "UTF-8")
source("03_mapa_mundial.R", encoding = "UTF-8")
cat("\nFinalizado. Confira a pasta resultados/.\n")
